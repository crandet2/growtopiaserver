var searchData=
[
  ['unreliablesequencenumber',['unreliableSequenceNumber',['../structENetOutgoingCommand.html#a8d7cf412de3b1ce53147becc1476d7da',1,'ENetOutgoingCommand::unreliableSequenceNumber()'],['../structENetIncomingCommand.html#a6e31e6e0ea7bf56f255d21b58285f003',1,'ENetIncomingCommand::unreliableSequenceNumber()'],['../structENetProtocolSendUnreliable.html#a0f03505c1afe4d4b7cc32229b6442c0b',1,'ENetProtocolSendUnreliable::unreliableSequenceNumber()']]],
  ['unsequencedgroup',['unsequencedGroup',['../structENetProtocolSendUnsequenced.html#a099dfce39def998b61285ef9cb5e3f84',1,'ENetProtocolSendUnsequenced']]],
  ['unsequencedwindow',['unsequencedWindow',['../structENetPeer.html#aadd45fdbc347e69b55820927d38197cd',1,'ENetPeer']]],
  ['usedreliablewindows',['usedReliableWindows',['../structENetChannel.html#adf6ee9725fb99751f778a97d2473a204',1,'ENetChannel']]],
  ['userdata',['userData',['../structENetPacket.html#a588f6c3be6263ecc7ed8d3412c3e47ea',1,'ENetPacket']]]
];
